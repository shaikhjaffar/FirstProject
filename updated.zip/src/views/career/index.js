import React from "react"
import "@styles/base/components/_card.scss"
import Footer from "../../pages/Footer/Footer"
import Button from "../../@core/components/button/Button"
class Career extends React.Component {
    render() {
        return (
            <>
            <div className="Product card">
            <Button/>
            <h1>Career</h1>
        </div>
        <Footer/>
            </>
        
        )
    }
}
export default  Career