import {React, Component} from "react"
import SecondPage from "../../@core/components/Nested/components/index"
import Collabtionanimation from "../../@core/components/Nested/components/min"
import Footer from "../../pages/Footer/Footer"
// import Productmain from '../../@core/components/productmain/index'

export default class Product extends Component {
  //  render() {
  //   return (
  //     <Productmain/>
  //   )
  //  }
  constructor(props) {
     super(props)
     const width = window.innerWidth
     this.state = {}
     if (width > 600) {
       this.state.renderComponent = (
        <>
        <SecondPage/>
        <Footer/>
        </>
        
       )
     } else {
       this.state.renderComponent = (
        <>
        <Collabtionanimation/>
        <Footer/>
        </>
        
       )
     }
   }

  render() {
    return this.state.renderComponent
  }

}
