// ** Dropdowns Imports
import React from "react"
// import { Button } from "reactstrap"
 import './style.css'
 import login from './Group 87.svg'
 import Register from "../Registration"
const button = () => {
  return (
    <>
      <Register/>
    <img src={login} className="button-animate bt2" alt="login"></img>
    </>

  )
}
export default button
