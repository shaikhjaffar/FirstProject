import {React, useState} from 'react'
import { slide as Menu } from 'react-burger-menu'
import './sidemenu.css'
import { NavLink } from "react-router-dom"
const Sidebar = () => {
  const [click, setClick] = useState(false)

  const handleClick = () => setClick(!click)
  return (
    <Menu>
            <a className="menu-item">
              <NavLink
                exact
                to="/"
                activeClassName="active"
                onClick={handleClick}
              >
                Home
              </NavLink>
            </a>
            <a className="menu-item">
              <NavLink
                exact
                to="/product/payroll"
                activeClassName="active"
                onClick={handleClick}
              >
                Product
              </NavLink>
            </a>
            <a className="menu-item">
              <NavLink
                exact
                to="/blogs"
                activeClassName="active"
                onClick={handleClick}
              >
                Blogs
              </NavLink>
            </a>
            <a className="menu-item">
              <NavLink
                exact
                to="/carrer"
                activeClassName="active"
                onClick={handleClick}
              >
                Carrer
              </NavLink>
            </a>
            <a className="menu-item">
              <NavLink
                exact
                to="/about-us"
                activeClassName="active"
                
                onClick={handleClick}
              >
                About us
              </NavLink>
            </a>
            <a className="menu-item">
              <NavLink
                exact
                to="/contact-us"
                activeClassName="active"
                onClick={handleClick}
              >
                Contact us
              </NavLink>
            </a>
    </Menu>
    
  )
}
export default Sidebar