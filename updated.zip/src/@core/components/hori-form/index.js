import React, { Component } from 'react'
import './horiform.css'
import CreatableSelect from 'react-select/creatable'
import Cities from './Cities.json'
import Designation from './Designation.json'
import { Input, Label, FormGroup} from 'reactstrap'
 class HoriForm extends Component {
  
  constructor(props) {
    super(props)
    this.state = {
      selectOption : [],
      selectedOption : [],
      name:"",
      contact:"",
      companyName:"",
      email:"",
      desig:"",
      city:""
    }
    this.handleSubmit = this.handleSubmit.bind(this)
    this.namehandler = this.namehandler.bind(this)
    this.contacthandler = this.contacthandler.bind(this)
    this.companyhandler = this.companyhandler.bind(this)
    this.emailhandler = this.emailhandler.bind(this)
  }
    getOptions() {
    const data = Cities.Citynames
    const option = data.map(d => ({
      label : d.name
    }))
    const datas = Designation.designames
    const options = datas.map(ds => ({
      label : ds.name
    }))
    this.setState({selectOption:option})
    this.setState({selectedOption:options})
  }
  // getsOptions(){
  //   const data = Cities.Citynames
  //   const option = data.map(d => ({
  //     "label" : ""
  //   }))
  //   const datas = Designation.designames
  //   const options = datas.map(ds => ({
  //     "label" : ""
  //   }))
  //   this.setState({selectOption:option})
  //   this.setState({selectedOption:options})
  // }
  namehandler(event) {
    this.setState({
      name: event.target.value
    })
  }
  contacthandler(event) {
    this.setState({
      contact: event.target.value
    })
  }
  companyhandler(event) {
    this.setState({
      companyName: event.target.value
    })
  }
  emailhandler(event) {
    this.setState({
      email: event.target.value
    })
  }
 handleChange(event) {
  this.setState({city:event.label})
 } 
 handlesChange1(event) {
  this.setState({desig:event.label})
 } 
 componentDidMount() {
  this.getOptions()
 }
  handleSubmit(event) {
    alert(`${this.state.companyName} ${this.state.name} ${this.state.email} ${this.state.contact} ${this.state.desig} ${this.state.city} Request Send!!!!`)
    console.log(this.state)
    this.setState({ 
      name: "",
      contact: "",
      companyName: "",
      email: "",
      desig:"",
      city:""
    })
 
 event.reset()
}

  render() {

    return (
        <form onSubmit={this.handleSubmit} className="contact-form">
          <div className='contact-form-div'>
          <div className='contact-input-container'>
            <input className='contact-input-box'type="text" 
            value={this.state.name} 
            onChange={this.namehandler} required/>
            {this.state.name === "" ? <label className='contact-label-name'>Name</label> : <label className='contact-label2'>Name</label>  }
          </div>
          <div className='contact-input-container'>
            <input className='contact-input-box' type="number" 
            value={this.state.contact} 
            onChange={this.contacthandler} required/>
            {this.state.contact === "" ? <label className='contact-label-name'>Contact No</label> : <label className='contact-label2'>Contact No</label>  }
          </div>
          <div className='contact-input-container'>
            <input className='contact-input-box'type="text" 
            value={this.state.companyName} 
            onChange={this.companyhandler} />
            {this.state.companyName === "" ? <label className='contact-label-name'>Company Name</label> : <label className='contact-label2'>Company Name</label>  }
          </div>
          <div className='contact-input-container'>
            <input className='contact-input-box' type="email" 
            value={this.state.email} 
            onChange={this.emailhandler} required/>
            {this.state.email === "" ? <label className='contact-label-name'>Email</label> : <label className='contact-label2'>Email</label>  }
          </div>
          <div className='contact-input-container'>
          <CreatableSelect className='contact-input-box' options={this.state.selectedOption} onChange={this.handlesChange1.bind(this)} />
            <label className='contact-label2'>Designation</label>
          </div>
          {/* <div className='contact-input-container'>
          <CreatableSelect className='contact-input-box' options={this.state.selectOption} onChange={this.handleChange.bind(this)} />
          <label>City</label>
          </div> */}
          <FormGroup
            check
            inline
            style={{margintop:"-4%"}}>
            <Input type="checkbox" className='contact-checkbox'/>
            <Label check> I Agree to Privacy Policy </Label>
          </FormGroup>
          <input type="submit" value="Send a request" className='contact-button'/>
          <h5 className='contact-login-text'> Already a user ? <a className="contact-link" href="#">Login</a></h5>
      </div> 
      </form>          
    )
}
}

export default HoriForm
