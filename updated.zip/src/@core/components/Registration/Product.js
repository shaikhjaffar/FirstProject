const Productnames =[
    {
        pid: "1",
        name: "1 Click Payroll",
        fid:["1","2","3","4","5","6","7"]     
    },
    {
        pid: "2",
        name: "1 Click Salary Advance",
        fid:["1","2","3","4","5","6","7"]
    },
    {
        pid: "3",
        name: "1 Click Insurance Funding",
        fid:["1","2","3","4","5","6","7"]
    },
    {
        pid: "4",
        name: "1 Click Lease Rental Discounting",
        fid:["1","2","3","4","5","8"]
    },
    {
        pid: "5",
        name: "1 Click Project Funding",
        fid:["1","2","3","4","5","9","10"]
    },
    {
        pid: "6",
        name: "1 Click Supply Chain Financing",
        fid:["1","2","3","4","5","9","10"]
    },
    {
        pid: "7",
        name: "1 Click Working Capital",
        fid:["1","2","3","4","5","9","10"]
    },
    {
        pid: "8",
        name: "1 Click Collateral Free MSME",
        fid:["1","2","3","4","5","9","10"]
    },
    {
        pid: "9",
        name: "1 Click Human Resource Management System",
        fid:["1","2","3","4","5","11"]
    },
    {
        pid: "10",
        name: "1 Click Entertainment & Production Financial",
        fid:["1","2","3","4","5","9","10","12"]
    }
]
export default Productnames