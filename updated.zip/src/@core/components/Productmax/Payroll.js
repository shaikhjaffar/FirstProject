import React from "react"
import './Secondpage.css'
import Vect1 from "./Vector (1).png"
import Vect2 from "./Group 24bag tick.png"
import Vect from "./Vector.png"

function Payroll () {
    return (
        <div
            id="Payroll"
          >
            <div>
              <div className="text">
                <p className="click shiftPayroll">1 Click</p>
                <p className="ProductName"> Payroll </p>
              </div>
              <div className="rectline2"> </div>
              <div className="circle"></div>
              <div className="rowProduct">
                <div className="col2">
                  <div className="containerClass">
                    <div className="inner-circle">
                      <img
                        className=" imagevec"
                        src={Vect}
                        alt="BigCo Inc. logo"
                      />
                    </div>
                    <div className="insidetext">
                      <p>
                        {" "}
                        Click on Registration<br></br>
                        Button and Fill<br></br>
                        Required Details.
                       
                      </p>
                    </div>
                  </div>
                </div>
                <div className="col2">
                  <div className="containerClass">
                    <div className="inner-circle">
                      <img
                        className=" imagevec"
                        src={Vect1}
                        alt="BigCo Inc. logo"
                      />
                    </div>
                    <div className="insidetext">
                      <p>
                      Upload<br></br>
                     Important<br></br>
                       Documents
                       
                      </p>{" "}
                    </div>
                  </div>
                </div>
                <div className="col2">
                  <div className="containerClass">
                    <div className="inner-circle">
                      <img
                        className=" imagevec"
                        src={Vect2}
                        alt="BigCo Inc. logo"
                      />
                    </div>
                    <div className="insidetext">
                      <p>
                        {" "}
                        Avail the Loan<br></br>
                       Selecting the<br></br>
                         EMI Option
                       
                      </p>
                    </div>
                  </div>
                </div>
              </div>{" "}
              <div className="circle"></div>
              <div className="Text3">
                <p> HOW IT WORKS</p>
              </div>
              <div className="rectline2"> </div>
              <div className="cardparatext">
                <div className="para1">
                  <p>
                    Approval : Application approval happens in less than 48
                    hours<br></br>
                    Immediate Access : Once you’re approved, simply log in and
                    get instant access to your funds. <br></br>Our app and
                    website gets you unded quickly and smoothly. <br></br>
                    Utilization : You can utilize your funds 24*7 and with round
                    the clock support from our end. <br></br>
                    Limited paperwork : We require minimal documentation to get
                    your app- lication approved.<br></br>
                    Low Cost IR : Interest Rates are as low as 1.5% per month
                    depending on your credit history and business revenue.{" "}
                    <br></br>Importantly, you only pay for the financing you
                    use.{" "}
                  </p>
                </div>
              </div>
            </div>
          </div>
    )
}
export default Payroll