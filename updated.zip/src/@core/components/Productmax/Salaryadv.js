
import React from "react"
import './Secondpage.css'
import Vect1 from "./Vector (1).png"
import Vect2 from "./Group 24bag tick.png"
import Vect from "./Vector.png"
function SalaryAdv() {
    return (
        <div
    id="Salary-advance"
  > 
    <div>
      <div className="text">
        <p className="click shift2">1 Click</p>
        <p className="ProductName"> Salary Advance </p>
      </div>
      <div className="rectline2"> </div>
      <div className="circle"></div>
      <div className="rowProduct">
        <div className="col2">
          <div className="containerClass">
            <div className="inner-circle">
              <img
                className=" imagevec"
                src={Vect}
                alt="BigCo Inc. logo"
              />
            </div>
            <div className="insidetext">
              <p>
                {" "}
                Get your<br></br> Login Credentials
              </p>
            </div>
          </div>
        </div>
        <div className="col2">
          <div className="containerClass">
            <div className="inner-circle">
              <img
                className=" imagevec"
                src={Vect1}
                alt="BigCo Inc. logo"
              />
            </div>
            <div className="insidetext">
              <p>
                Login With Your<br></br>Username & Password
              </p>
            </div>
          </div>
        </div>
        <div className="col2">
          <div className="containerClass">
            <div className="inner-circle">
              <img
                className=" imagevec"
                src={Vect2}
                alt="BigCo Inc. logo"
              />
            </div>
            <div className="insidetext">
              <p>
                {" "}
                Get Limit Approved<br></br>& Dispense Money
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="circle"> </div>

      <div className="Text3">
        <p> HOW IT WORKS</p>
      </div>
      <div className="rectline2"> </div>
      <div className="cardparatext">
        <div className="para1">
          <p>
            •1 Click Salary Advance helps organizations to control
            employee <br></br>
            turnover by offering the opportunity of drawing contingency
            salaries.<br></br>It is a short-term credit repayed by
            opting for a 3-month EMI option.
            <br></br> • Employees gets 24x7 access to liquidity.
            <br></br>• No more waiting for month end for your salaries
            to be credited. <br></br>• 1 Click Salary advance comes with
            low-cost interest rate.
          </p>
        </div>
      </div>
    </div>
  </div>
    )
}
 export default SalaryAdv