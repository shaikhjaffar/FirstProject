import React from 'react'
import './Secondpage.css'
import Button3 from './3button'
function SCFiance() {
  return (
    <div className="main-product-page">
    <div className="heading-box">
   <span className="Common-word-product">1 Click</span><span className="product-name">  Supply chain finance</span>
   <div className="rectline1"></div>
    </div>

         <Button3/>
    <div className="para1-salaryadv">
<p>•Supply chain finance (SCF) are used to reduce financing costs and boost company
 efficiency for buyers and sellers involved in a sales transaction. SCF techniques
 operate by automating business operations and monitoring the approval and
 settlement of invoices from start to finish.</p><p>
 •SCF is a combination of technology based business and financing that lowers costs
 and improves competency for all the parties involved in the transaction.</p><p>
 •This is a short term line of credit that optimizes working capital for both the seller
 and buyer equally.</p>.<p>
 •The main benefit of Supply chain finance is the convenience that is added to the
 sales process. It adds protection for the buyer and seller, increases business transi-
 tions. It’s like a win-win situation for all the parties involved. 
</p>
    </div></div>
  )
}

export default SCFiance