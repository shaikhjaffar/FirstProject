import React, {useState} from "react"
import { Link, Outlet } from "react-router-dom"
import PayrollIMG from "./Payroll.png"
import CF from "./CF.png"
import ProjectFun from "./ProjectFun.png"
import InsuranceFun from "./InsuranceFun.png"
import LRD from "./LRD.png"
import WorkingCap from "./WorkingCap.png"
import SCF from "./SCF.png"
import HRm from "./HRm.png"
import Production from "./production logo-01 1entertainment ptod.png"
import "./Secondpage.css"
function SecondPage() {
    const [click, setClick] = useState(false)

  const handleClick = () => setClick(!click)
  return (
    <div className="card">

    <ul className={click ? "product-nav-menu  active-product" : "product-nav-menu"}>
                <li className="product-nav-item">
                  <img src={PayrollIMG} className="pro-image" />
                  <Link exact to="payroll" className="product-nav-link"
                   activeClassName="active-product"
                  onClick={handleClick}>
                    Payroll
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={PayrollIMG} className="pro-image" />
                  <Link exact to="salaryadv"className="product-nav-link"onClick={handleClick}>
                    Salary Advance
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={InsuranceFun} className="pro-image  " />
                  <Link exact to="insurancefun"className="product-nav-link"onClick={handleClick}>
                    Insurance Funding
                  </Link>
                </li>

                <li className="product-nav-item">
                <img src={ProjectFun} className="pro-image"/>
                  <Link exact to="projectfun"className="product-nav-link"onClick={handleClick}>
                    Project Funding
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={LRD} className="pro-image " />
                  <Link exact to="lrd"className="product-nav-link"onClick={handleClick}>
                    LRD
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={SCF} className="pro-image " />
                  <Link exact to="scf"className="product-nav-link"onClick={handleClick}>
                    Supply Chain Financing
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={WorkingCap} className="pro-image " />
                  <Link exact to="workingcap"className="product-nav-link"onClick={handleClick}>
                    Working Cap
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={CF} className="pro-image " />
                  <Link exact to="cf"className="product-nav-link"onClick={handleClick}>
                    MSME/SME
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={HRm} className="pro-image" />
                  <Link exact to="hrm"className="product-nav-link"onClick={handleClick}>
                    HRMS
                  </Link>
                </li>

                <li className="product-nav-item">
                  <img src={Production} className="pro-image " />
                  <Link to="production"className="product-nav-link"onClick={handleClick}>
                    Entmt & Production
                  </Link>
                </li>     
    </ul>
    <Outlet />
     </div>
  )
}
export default SecondPage
