import React from "react"
import "./Secondpage.css"
import Button3 from './3button'
function Collateral() {
  return (
    <div className="main-product-page">
    <div className="heading-box">
   <span className="Common-word-product">1 Click</span><span className="product-name">  Collateral Free MSME/SME Loan</span>
   <div className="rectline1"></div>
    </div>
      <Button3/>
      <div className="para1-salaryadv">
        <p>
          • A MSME or SME loan is a credit service offered to micro, small or
          medium enterprises, it maybe offered to individuals, startups,
          existing businesses, self-employed professio- nals, and other
          businesses. </p>
          <p>• 1 Click Capital offers Collateral Free MSME and
          SME loans with the primary purpose of helping business get capital for
          business expansion, or starting a new business, fulfilling day to day
          business requirements, meeting working capital needs, improving cash
          flow, investing in raw material, inventories or stocks, upgrading old
          equipment or buying new machinery etc. </p>
          <p>• The repayment terms
          can be upto 3 months. </p>
          <p>• We offer you a line of credit without
          any collateral and at minimum paper work.
        </p>
      </div>
    </div>
  )
}

export default Collateral
