import React from "react"
import "./Secondpage.css"
import Button3 from './3button'
function Workingcapital() {
  return (
    <div className="main-product-page">
    <div className="heading-box">
   <span className="Common-word-product">1 Click</span><span className="product-name">  Working capital</span>
   <div className="rectline1"></div>
    </div>
     <Button3/>
      <div className="para1-salaryadv">
        <p>
          •Working capital is that money used to conduct the day to day
          functions and operations of a business.</p>
         <p> •Without the availability of free flow of working capital a company
          may find it difficult to function efficiently. </p>.
          <p>•In order to function smoothly and have a seamless operations of the
          business one can acquire a working capital loan. </p>
          <p>•An organization’s working capital is the reflection of its financial
          stability and liquidity. </p>
          <p>•A Working Capital Loan is issued to fund the
          day to day activities and operations of a business for example
          covering accounts payable, inventory, paying employees. </p>
          <p>•It is not possible for every business to have a stable level of sales
          and revenue through- out the year, due to which there can arise a need
          for capital to keep the operations going smoothly.</p>
          <p>•Business with a seasonal sales cycle especially need these kinds of
          loan. 1 Click capital’s working capital loan is an unsecured loan that
          requires no collateral.
        </p>
      </div>
    </div>
  )
}

export default Workingcapital
