import React from 'react'
import './Secondpage.css'
import Button3 from './3button'
function Payroll() {
  return (
    <div className="main-product-page">
    <div className="heading-box">
   <span className="Common-word-product">1 Click</span><span className="product-name">  Payroll</span>
   <div className="rectline1"></div>
    </div>
     <Button3/>
        <div className="para1">
    <h3>Approval :</h3> <p>Application approval happens in less than 48 hours</p>
    <h3>Immediate Access :</h3> Once you’re approved, simply log in and get instant
access to your funds. Our app and website gets you 
 unded quickly and smoothly.
 <h3>Utilization :</h3>
 You can utilize your funds 24*7 and with round the
clock support from our end.
<h3>Limited paperwork : </h3>
We require minimal documentation to get your app-
lication approved.
<h3>Low Cost IR :</h3>
 Interest Rates are as low as 1.5% per month depending
on your credit history and business revenue. Importantly,
you only pay for the financing you use.
      </div></div>
  )
}

export default Payroll