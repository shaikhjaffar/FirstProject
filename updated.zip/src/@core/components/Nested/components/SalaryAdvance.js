import React from 'react'
import './Secondpage.css'
import Vect1 from './Vector (1).png'
import Vect2 from './Group 24bag tick.png'
import Vect from './Vector.png'
import Button3 from './3button'
function SalaryAdvance() {
  return (
    <div className="main-product-page">
          <div className="heading-box">
         <span className="Common-word-product">1 Click</span><span className="product-name">  Salary Advance</span>
         <div className="rectline1"></div>
          </div>
         <Button3/>
       <div className="para1-salaryadv">
        <p>•1 Click Salary Advance helps organizations to control employee turnover by offering the opportunity of drawing contingency salaries.</p>
        <p>•It is a short-term credit repayed by opting for a 3-month EMI option.</p>
        <p>•Employees gets 24x7 access to liquidity.</p>
        <p>•No more waiting for month end for your salaries to be credited.</p>
        <p>•1 Click Salary advance comes with low-cost interest rate.</p>

</div>
    </div>
  )
}

export default SalaryAdvance
