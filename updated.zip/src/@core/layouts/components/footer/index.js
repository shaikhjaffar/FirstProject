// ** Icons Import
// import './footer.css'
import "@styles/base/components/_card.scss"
const Footer = () => {

  return (
    <div className="footer card" style={{height:1473}}>
    <h1>Footer</h1>
  </div>
  )
}

export default Footer
