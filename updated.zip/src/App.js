// import "./App.css";
import NavBar from "./pages/navbar/nav"
import { Routes, Route } from 'react-router-dom'
// import {Switch} from 'react-router-dom'
import About from './views/about/About'
import Blog from './views/blog'
import Stats from './views/career/index'
import Home from './views/Home'
import Product from "./views/product-page/index"
import Contactus from './views/contact/index'
import Sidebar from "./@core/components/hamburgernav/sidemenu/sidemenu"
import Payroll from './@core/components/Nested/components/Payroll'
import CF from './@core/components/Nested/components/Collateral'
import ProjectFun from './@core/components/Nested/components/Project'
import InsuranceFun from './@core/components/Nested/components/Insurance'
import LRD from './@core/components/Nested/components/LRD'
import WorkingCap from './@core/components/Nested/components/Workingcapital'
import SCF from './@core/components/Nested/components/SCFiance'
import HRm from './@core/components/Nested/components/HRMS'
import Production from './@core/components/Nested/components/Entertement'
import SalaryAdv1 from './@core/components/Nested/components/SalaryAdvance'
function App() {
  return (
    <>
<div className="App" id="outer-container">
      <Sidebar pageWrapId={'page-wrap'} outerContainerId={'outer-container'} />
      <div id="page-wrap">
      <NavBar />
      <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/product/' element={<Product/>}>
          <Route path='payroll' element={<Payroll/>} />
          <Route path='cf' element={<CF/>} />
          <Route path='projectfun' element={<ProjectFun/>} />
          <Route path='insurancefun' element={<InsuranceFun/>} />
          <Route path='lrd' element={<LRD/>} />
          <Route path='workingcap' element={<WorkingCap/>} />
          <Route path='scf' element={<SCF/>} />
          <Route path='hrm' element={<HRm/>} />
          <Route path='production' element={<Production/>} />
          <Route path='salaryadv' element={<SalaryAdv1/>} />
          </Route>
          <Route path='/blogs' element={<Blog/>} />
          <Route path='/carrer' element={<Stats/>} />
          <Route path='/about-us' element={<About/>} />
          <Route path='/contact-us' element={<Contactus/>} />
      </Routes>
      </div>
    </div>
      
    </>
  )
}

export default App